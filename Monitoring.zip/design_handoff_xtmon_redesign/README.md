# Handoff: XTMon Frontend Redesign

## Overview

This package contains a **high-fidelity design reference** for improving the frontend of the XTMon Blazor application — a monitoring and recovery dashboard for APS Actions / XTarget SQL Server processing.

The goal is to apply visual and structural improvements to the existing Blazor app (`src/XTMon/`) without changing any backend, routing, or component logic. All changes are limited to CSS (`tailwind.css`, scoped `.razor.css` files), HTML structure in `.razor` files, and one font import in `App.razor`.

---

## About the Design Files

`XTMon Redesign.html` is an **interactive HTML prototype** — a design reference showing intended look, layout, and behaviour. It is **not** production code. Your task is to **recreate these designs within the existing Blazor codebase**, using its existing Tailwind CSS setup, custom CSS properties, and Razor component structure. Do not ship the HTML file itself.

## Fidelity

**High-fidelity.** The prototype uses final colours, typography, spacing, component structure, and interactions. Recreate it pixel-closely using the existing Blazor patterns.

---

## What Changed (and Why)

| Area | Before | After | Reason |
|---|---|---|---|
| Font | Inter | **Manrope + DM Mono** | Inter is overused; Manrope is cleaner and more distinctive for a data-dense internal tool |
| Sidebar width | 21rem | **17.5rem** | Was too wide; wastes horizontal space |
| Sidebar scroll | Not scrollable | **`overflow-y: auto`** | Long nav overflows viewport without it |
| Dark mode palette | Blue-tinted (`#0c1222`) | **Neutral dark (`#0d1117`)** | Blue tint feels unnatural; neutral dark is easier on the eyes |
| Nav submenu | 20+ flat identical items | **Grouped by function** | Impossible to scan without groups |
| Home page cards | One flat grid of 18 cards | **Three labelled sections** | No hierarchy; groups make the page scannable |
| Layout header | Hardcoded "Operational Pulse" in `MainLayout` | **Removed** | Each page already has its own title; the global header was redundant noise |
| Stat card hover | Basic lift effect | **Accent top-line + shadow** | More tactile, reinforces the colour system |
| Data table font | Same UI font | **DM Mono** | Tabular data is much easier to read in a monospace font |
| Usage indicator | None | **Inline progress bar** (green/amber/red) | Immediate visual signal without reading numbers |

---

## Files to Change

All files are inside `src/XTMon/`.

```
src/XTMon/
├── Components/
│   ├── App.razor                         ← add font import
│   ├── Layout/
│   │   ├── MainLayout.razor              ← remove hardcoded header
│   │   └── NavMenu.razor                 ← add submenu group labels
│   └── Pages/
│       └── Home.razor                    ← reorganise into 3 sections
├── Styles/
│   └── tailwind.css                      ← main token + component changes
└── wwwroot/
    └── app.css                           ← regenerated from tailwind.css; no manual edits
```

---

## Change 1 — Font Import (`App.razor`)

Add inside `<head>`, before the existing CSS link:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link
  href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap"
  rel="stylesheet">
```

---

## Change 2 — CSS Tokens & Components (`tailwind.css`)

### 2a. Font stack

Replace the existing `body, h1, h2, h3, h4` font declaration:

```css
body, h1, h2, h3, h4 {
  font-family: 'Manrope', system-ui, -apple-system, sans-serif;
}
```

Add mono font to data grids (inside `@layer components`):

```css
.db-grid {
  font-family: 'DM Mono', ui-monospace, monospace;
  font-size: 0.8125rem;
}
```

### 2b. Dark mode token block

Replace the entire `.dark { … }` block with:

```css
.dark {
  color-scheme: dark;
  --bg-body:          #0d1117;
  --bg-sidebar:       #161b22;
  --bg-surface:       #1c2128;
  --bg-surface-hover: #21262d;
  --bg-grid-head:     #161b22;
  --border-subtle:    rgba(255, 255, 255, 0.07);
  --border-medium:    rgba(255, 255, 255, 0.10);

  --text-heading: #e6edf3;
  --text-body:    #8b949e;
  --text-muted:   #6e7681;
  --text-subtle:  #484f58;

  --accent-text:  #2dd4bf;
  --accent-icon:  #2dd4bf;
  --accent-label: #5eead4;

  --pill-bg:   rgba(255, 255, 255, 0.06);
  --pill-ring: rgba(255, 255, 255, 0.08);
  --pill-text: #8b949e;

  --grid-text:      #c9d1d9;
  --grid-head-text: #6e7681;
  --grid-stripe:    rgba(255, 255, 255, 0.02);
  --grid-hover:     rgba(255, 255, 255, 0.04);

  --nav-text:              #8b949e;
  --nav-text-hover:        #e6edf3;
  --nav-hover-bg:          rgba(255, 255, 255, 0.05);
  --nav-submenu-border:    rgba(255, 255, 255, 0.10);
  --nav-submenu-text:      #8b949e;
  --nav-submenu-text-hover:#e6edf3;
  --nav-submenu-hover-bg:  rgba(255, 255, 255, 0.05);
  --nav-submenu-active-text: #99f6e4;
  --nav-submenu-active-bg:   rgba(13, 148, 136, 0.20);
  --nav-submenu-active-rail: #2dd4bf;

  --btn-outline-text:         #2dd4bf;
  --btn-outline-border:       rgba(45, 212, 191, 0.28);
  --btn-outline-bg:           rgba(13, 148, 136, 0.12);
  --btn-outline-hover-bg:     rgba(13, 148, 136, 0.22);
  --btn-outline-hover-border: rgba(45, 212, 191, 0.45);

  --input-bg:       rgba(255, 255, 255, 0.04);
  --input-border:   rgba(255, 255, 255, 0.10);
  --input-text:     #e6edf3;
  --input-option-bg:#1c2128;

  --logo-icon-bg: rgba(13, 148, 136, 0.20);

  --success-text: #3fb950;
  --error-text:   #f85149;
  --info-text:    #58a6ff;
  --warning-text: #d29922;
}
```

### 2c. Sidebar width and scroll

Update `.sidebar-card`:

```css
.sidebar-card {
  width: 17.5rem;
  min-width: 17.5rem;
  overflow-y: auto;
  overflow-x: hidden;
}

/* Thin scrollbar */
.sidebar-card::-webkit-scrollbar       { width: 4px; }
.sidebar-card::-webkit-scrollbar-track { background: transparent; }
.sidebar-card::-webkit-scrollbar-thumb { background: var(--border-medium); border-radius: 2px; }
```

### 2d. Stat card accent top-line

Add to `.stat-card`:

```css
.stat-card {
  /* existing styles … */
}

.stat-card::before {
  content: '';
  position: absolute;
  inset: 0 0 auto;
  height: 2px;
  background: var(--accent-icon);
  opacity: 0;
  transition: opacity 0.2s ease;
}

.stat-card:hover::before {
  opacity: 1;
}
```

### 2e. Submenu group labels

Add a new component class:

```css
.submenu-group-label {
  font-size: 0.6rem;
  font-weight: 700;
  letter-spacing: 0.09em;
  text-transform: uppercase;
  color: var(--text-subtle);
  padding: 0.375rem 0.5rem 0.125rem;
  margin-top: 0.25rem;
}
```

---

## Change 3 — Remove hardcoded header (`MainLayout.razor`)

Delete the entire `<header>` block that contains "Operational Pulse". It looks like this:

```razor
<header class="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
    <div>
        <p class="section-label">Dashboard</p>
        <h2 class="text-2xl font-bold text-heading mt-1">Operational Pulse</h2>
        <p class="text-sm text-body-secondary mt-1">Monitor capacity, growth, and processing health in real-time.</p>
    </div>
    <div class="flex flex-wrap items-center gap-3 text-xs">
        <!-- pill badges … -->
    </div>
</header>
```

Each page already renders its own `<h1>` / section label at the top — these are sufficient. If you want to keep the pill badges (Interactive Server, ADO SqlClient, username), move them into the individual pages that need them, or into a shared `<PageHeader>` component you can include selectively.

---

## Change 4 — Submenu group labels (`NavMenu.razor`)

Inside the `<div class="submenu-group">` for Data Validation, insert `<p class="submenu-group-label">` dividers between items. Suggested groupings:

```razor
<div class="submenu-group">

  <p class="submenu-group-label">Controls</p>
  <a class="..." href="data-validation-runner">Run Checks</a>
  <a class="..." href="batch-status">Batch Status</a>   <!-- AuthorizeView wrapper -->

  <p class="submenu-group-label">Market</p>
  <a class="..." href="referential-data">Referential Data</a>
  <a class="..." href="market-data">Market Data</a>
  <a class="..." href="pricing-file-reception">Pricing File Reception</a>

  <p class="submenu-group-label">Portfolio</p>
  <a class="..." href="out-of-scope-portfolio">Out of Scope Portfolio</a>
  <a class="..." href="missing-sog-check">Missing SOG Check</a>
  <a class="..." href="non-xtg-portfolio">Non XTG Portfolio</a>
  <a class="..." href="rejected-xtg-portfolio">Rejected XTG Portfolio</a>

  <p class="submenu-group-label">Flows</p>
  <a class="..." href="mirrorization">Mirrorization</a>
  <a class="..." href="result-transfer">Result Transfer</a>
  <a class="..." href="rollovered-portfolios">Rollovered Portfolios</a>
  <a class="..." href="feedout-extraction">FeedOut Extraction</a>

  <p class="submenu-group-label">Finance</p>
  <a class="..." href="adjustments">Adjustments</a>
  <a class="..." href="pricing">Pricing</a>
  <a class="..." href="future-cash">Future Cash</a>
  <a class="..." href="fact-pv-ca-consistency">Fact PV/CA Consistency</a>
  <a class="..." href="daily-balance">Daily Balance</a>

  <p class="submenu-group-label">Integrity</p>
  <a class="..." href="multiple-feed-version">Multiple Feed Version</a>
  <a class="..." href="missing-workflow-check">Missing Workflow Check</a>
  <a class="..." href="column-store-check">Column Store Check</a>
  <a class="..." href="trading-vs-fivr-check">Trading vs Fivr Check</a>
  <a class="..." href="adjustment-links-check">Adjustment Links Check</a>

  <p class="submenu-group-label">Output</p>
  <a class="..." href="publication-consistency">Publication Consistency</a>
  <a class="..." href="jv-balance-consistency">JV Balance Consistency</a>
  <a class="..." href="reverse-conso-file">Reverse Conso File</a>
  <a class="..." href="sas-tables">SAS Tables</a>
  <a class="..." href="precalc-monitoring">Precalc Monitoring</a>
  <a class="..." href="vrdb-status">VRDB Status</a>

</div>
```

Keep all existing C# bindings (`@GetDataValidationSubmenuLinkClass(...)`, `<DataValidationNavLabel … />`, `<AuthorizeView>` wrappers) exactly as they are — only add the `<p class="submenu-group-label">` dividers.

---

## Change 5 — Reorganise Home page (`Home.razor`)

Replace the single flat grid with three labelled sections. Keep all existing card markup — just reorganise them into groups with section labels:

```razor
<div class="space-y-5">

  <!-- Page title -->
  <div>
    <p class="section-label">Overview</p>
    <h1 class="text-2xl font-bold text-heading mt-1">APS Actions Monitoring</h1>
    <p class="text-sm text-body-secondary mt-1">
      Central monitoring and recovery dashboard for XTarget SQL Server processing.
    </p>
  </div>

  <!-- Infrastructure -->
  <div>
    <p class="section-label mb-3">Infrastructure</p>
    <div class="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
      <!-- Database Space card -->
      <!-- Database Backups card -->
      <!-- System Diagnostics card -->
    </div>
  </div>

  <!-- Operations (AuthorizeView-wrapped) -->
  <AuthorizeView Policy="UamRestricted">
    <Authorized>
      <div>
        <p class="section-label mb-3">Operations</p>
        <div class="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
          <!-- Replay Flows card -->
          <!-- JV Calculation card -->
        </div>
      </div>
    </Authorized>
  </AuthorizeView>

  <!-- Data Validation -->
  <div>
    <p class="section-label mb-3">Data Validation</p>
    <div class="grid sm:grid-cols-2 xl:grid-cols-4 gap-3">
      <!-- all 15+ data validation cards -->
      <!-- these can be visually smaller: add style="padding: 0.75rem" to each card -->
    </div>
  </div>

  <!-- Existing "How It Works", "Quick Start", "Data Sources", "Need Help?" surfaces below -->
  ...
</div>
```

---

## Design Tokens Reference

| Token | Light | Dark |
|---|---|---|
| `--bg-body` | `#f4f5f7` | `#0d1117` |
| `--bg-sidebar` | `#ffffff` | `#161b22` |
| `--bg-surface` | `#ffffff` | `#1c2128` |
| `--accent-text` | `#0d9488` | `#2dd4bf` |
| `--accent-icon` | `#14b8a6` | `#2dd4bf` |
| `--text-heading` | `#101828` | `#e6edf3` |
| `--text-muted` | `#667085` | `#6e7681` |
| Font (UI) | `Manrope` | same |
| Font (data) | `DM Mono` | same |
| Sidebar width | `17.5rem` | same |

---

## Assets

- **Fonts**: loaded from Google Fonts at runtime (no download needed)
  - `Manrope` — weights 400, 500, 600, 700, 800
  - `DM Mono` — weights 400, 500
- **Icons**: existing Heroicons SVG paths in `.razor` files — no changes needed
- **No new images or static assets** required

---

## Files in This Package

| File | Purpose |
|---|---|
| `README.md` | This document — full implementation spec |
| `XTMon Redesign.html` | Interactive HTML prototype — visual reference |

Open `XTMon Redesign.html` in a browser to see the target design. Use the moon/sun button to toggle dark mode. Click nav items to explore pages. Use the **Tweaks** toolbar button (top-right) to experiment with accent colour, sidebar width, and card radius.
